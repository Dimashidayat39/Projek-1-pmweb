<?php

require_once './action/dbkoneksi.php';

$data_pasien = $dbh->query('SELECT * FROM pasien');
$data_dokter = $dbh->query('SELECT * FROM peramedik WHERE kategori= "Dokter"');

$periksa_id = $_GET['id'] ?? 0;
if ($periksa_id) {
    $findPeriksaSQL = "SELECT * FROM periksa WHERE id =$periksa_id LIMIT 1";
    $periksa = $dbh->query($findPeriksaSQL);
    if ($periksa->rowCount()) $periksa = $periksa->fetch();
    else header('location: ./data_periksa.php');
}

include_once './layout/top.php';
include_once './layout/navbar.php';
include_once './layout/sidebar.php';

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Periksa</h1>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Form <?= $periksa_id ? 'Ubah' : 'Tambah' ?>Periksa</h3>
            </div>
            <div class="card-body">
                <form method="post" action="action/proses_periksa.php">
                    <form>
                        <div class="form-group row">
                            <label for="date" class="col-4 col-form-label">Tanggal</label>
                            <div class="col-8">
                                <input id="tanggal" name="tanggal" type="date" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="text" class="col-4 col-form-label">Berat</label>
                            <div class="col-8">
                                <input id="berat" name="berat" type="berat" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="text1" class="col-4 col-form-label">Tinggi</label>
                            <div class="col-8">
                                <input id="tinggi" name="tinggi" type="number" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="text2" class="col-4 col-form-label">Tensi</label>
                            <div class="col-8">
                                <input id="tensi" name="tensi" type="number" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                        <label for="alamat" class="col-4 col-form-label">Keterangan</label>
                        <div class="col-8">
                            <textarea id="keterangan" name="keterangan" cols="40" rows="2" class="form-control"><?= $periksa['periksa'] ?? '' ?></textarea>
                        </div>
                        </div>
                        <div class="form-group row">
                            <label for="id" class="col-4 col-form-label">Id Pasien</label>
                            <div class="col-8">
                            <select id="pasien" name="pasien" class="custom-select">
                                <option value="" disabled selected> ---  ---</option>
                                <?php foreach ($data_pasien as $key =>$pasien ) : ?>
                                    <option <?= ($periksa_id && $periksa['pasien_id'] ==    
                                    $pasien['id'] ? 'selected' : '') ?? '' ?> value="<?=
                                    $pasien['id'] ?>"><?= $pasien['nama'] ?></option>
                                <?php endforeach ?>
                            </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="id" class="col-4 col-form-label">Id Doktor</label>
                            <div class="col-8">
                            <select id="dokter" name="dokter" class="custom-select">
                                <option value="" disabled selected> ---  ---</option>
                                <?php foreach ($data_dokter as $key =>$dokter ) : ?>
                                    <option <?= ($periksa_id && $periksa['dokter_id'] ==    
                                    $dokter['id'] ? 'selected' : '') ?? '' ?> value="<?=
                                    $dokter['id'] ?>"><?= $dokter['nama'] ?></option>
                                <?php endforeach ?>
                            </select>
                            </div>
                        </div>
                    <div class="form-group row">
                        <div class="offset-4 col-8">
                            <input type="submit" name="proses" id="proses" class="btn bnt-primary" value="<?= $periksa_id ? 'Ubah' : 'Simpan' ?>">
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include_once './layout/bottom.php';
