<?php

require_once './dbkoneksi.php';

$tanggal= $_POST['tanggal']; //2
$berat = $_POST['berat']; //5
$tinggi = $_POST['tinggi']; //3
$tensi = $_POST['tensi']; //4
$katerangan = $_POST['keterangan']; //1
$pasien_id = $_POST['pasien'];
$dokter_id = $_POST['dokter']; //8


$data = [$tanggal, $berat, $tinggi, $tensi, $katerangan, $pasien_id, $dokter_id];

if (isset($_POST['id'])) $data[] = $_POST['id'];


/// check nilai pasien
switch ($_POST['proses']) {
    case 'Simpan';
        $insertSQL = "INSERT INTO periksa(tanggal, berat, tinggi, tensi, keterangan, pasien_id, dokter_id) VALUES (?,?,?,?,?,?,?)";
        // Mendefinisikan prepare statement
        $stmt = $dbh->prepare($insertSQL);
        // execute stetment
        $stmt->execute($data);
        break;
    case 'Ubah';
        $updateSQL = "UPDATE periksa SET tanggal=?, berat=?, tinggi=?, tensi_=?, keterangan=?,
        pasien_id=?, dokter_id=? WHERE id=?"; 
        $stmt = $dbh->prepare($updateSQL);
        $stmt->execute($data);
        break;
    case 'Hapus';
        $hapusSQL = "DELETE FROM periksa WHERE id=?";
        $stmt = $dbh->prepare($hapusSQL);
        $stmt->execute([$_POST['id']]);
        break;
    default:
        header('location: ../data_periksa.php');
}

// Red
header('location: ../data_periksa.php');
