<?php

require_once './action/dbkoneksi.php';

$sql = 'SELECT periksa.*, pasien.nama as nama_pasien, peramedik.nama as nama_dokter FROM periksa JOIN pasien ON
periksa.pasien_id=pasien_id JOIN peramedik ON periksa.dokter_id=peramedik.id';
$data = $dbh->query($sql);


include_once './layout/top.php';
include_once './layout/navbar.php';
include_once './layout/sidebar.php';

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Periksa</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
           <h3 class="card-title">Data Periksa</h3>
        </div>
        <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>NO.</th>
                    <th>Tanggal</th>
                    <th>Berat</th>
                    <th>Tinggi</th>                   
                    <th>Tensi</th>
                    <th>Keterangan</th>
                    <th>Pasien </th>
                    <th>Dokter</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $key => $periksa) : ?>
                    <tr>
                        <td><?= ++$key ?> </td>
                        <td><?=$periksa['tanggal'] ?></td>
                        <td><?=$periksa['berat'] ?></td>
                        <td><?=$periksa['tinggi'] ?></td>
                        <td><?=$periksa['tensi'] ?></td>
                        <td><?=$periksa['keterangan'] ?></td>
                        <td><?=$periksa['nama_pasien'] ?></td>
                        <td><?=$periksa['nama_dokter'] ?></td>
                        <td>
                          <a href="./form_periksa.php?id=<?= $periksa['id']?>" class="btn btn-sm btn-warning">Ubah</a>
                          <form action="./action/proses_periksa.php?id=<?= $periksa['id'] ?>" method="post"></form>
                          <input type="submit" name="proses" class="btn btn-sm-danger" value="Hapus">
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->



<?php
include_once './layout/bottom.php';
?>