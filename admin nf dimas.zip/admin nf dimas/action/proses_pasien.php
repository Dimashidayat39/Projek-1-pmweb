
<?php


require_once './dbkoneksi.php';

//tangkap data form yang di kirim 
$kode = $_POST['kode']; //1
$nama = $_POST['nama']; //2
$tmp_lahir = $_POST['tmp_lahir']; //3
$tgl_lahir = $_POST['tgl_lahir']; //4
$gender = $_POST['gender']; //5
$kelurahan_id = $_POST['kelurahan']; //6
$email = $_POST['email']; //7
$alamat = $_POST['alamat']; //8
 
//simpan data ke dalam array \
$data = [$kode, $nama, $tmp_lahir, $tgl_lahir, $gender, $email, $alamat, $kelurahan_id,];
 
//check nilai proses
switch ($_POST['proses']) {
    case 'Simpan';
    $insertPasienSQL = "INSERT INTO pasien (kode, nama, tmp_lahir, tgl_lahir, gender, 
    email, alamat, kelurahan_id) VALUES (?,?,?,?,?,?,?,?)";
    // Mendefinisikan prepare statement
    $stmt = $dbh->prepare($insertPasienSQL);
    // execute stetment
    $stmt->execute($data);
    break;
case 'Ubah';
    $updatePasienSQL = "UPDATE pasien SET kode=?, nama=?, tmp_lahir=?, tgl_lahir=?, gender=?,
    email=?, alamat=?, kelurahan_id=? WHERE id=?";
    $stmt = $dbh->prepare($updatePasienSQL);
    $stmt->execute($data);
    break;
case 'Hapus';
    $hapusPasienSQL = "DELETE FROM pasien WHERE id=?";
    $stmt = $dbh->prepare($hapusPasienSQL);
    $stmt->execute([$_POST['id']]);
    break;
default:
    header('location: ../data_pasien.php');
}

// Red
header('location: ../data_pasien.php');
