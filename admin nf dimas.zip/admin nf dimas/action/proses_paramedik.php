<?php

require_once './dbkoneksi.php';

$nama = $_POST['nama']; //2
$gender = $_POST['gender']; //5
$tmp_lahir = $_POST['tmp_lahir']; //3
$tgl_lahir = $_POST['tgl_lahir']; //4
$kategori = $_POST['kategori']; //1
$telpon = $_POST['telpon'];
$alamat = $_POST['alamat']; //8
$unit_kerja_id = $_POST['unit_kerja']; //7

echo $telpon;

$data = [$nama, $gender, $tmp_lahir, $tgl_lahir, $kategori, $telpon, $alamat, $unit_kerja_id ];

if (isset($_POST['id'])) $data[] = $_POST['id'];


/// check nilai pasien
switch ($_POST['proses']) {
    case 'Simpan';
        $insertSQL = "INSERT INTO peramedik (nama, gender, tmp_lahir, tgl_lahir, kategori, telpon,
        alamat, unit_kerja_id) VALUES (?,?,?,?,?,?,?,?)";
        // Mendefinisikan prepare statement
        $stmt = $dbh->prepare($insertSQL);
        // execute stetment
        $stmt->execute($data);
        break;
    case 'Ubah';
        $updateSQL = "UPDATE peramedik SET nama=?, gender=?, tmp_lahir=?, tgl_lahir=?, kategori=?,
        telpon=?, alamat=?, unit_kerja_id=? WHERE id=?"; 
        $stmt = $dbh->prepare($updateSQL);
        $stmt->execute($data);
        break;
    case 'Hapus';
        $hapusSQL = "DELETE FROM peramedik WHERE id=?";
        $stmt = $dbh->prepare($hapusSQL);
        $stmt->execute([$_POST['id']]);
        break;
    default:
        header('location: ../data_paramedik.php');
}

// Red
header('location: ../data_paramedik.php');
